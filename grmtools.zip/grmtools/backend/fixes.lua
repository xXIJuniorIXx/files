local m_utils = require("utils")
local fs = require("fs")
local http_client = require("http_client")
local logger = require("plugin_logger")
local utils = require("plugin_utils")
local paths = require("paths")
local cjson = require("json")

local engine = require("fix_engine")
local fixes = {}
local completed_removals = {}

local steam_utils = require("steam_utils")
-- Records are optional: games without an applied fix have no manifest/state file.
local function read_optional_record(path)
    if not fs.exists(path) then return {} end
    local ok, record = pcall(utils.read_json, path)
    if not ok or type(record) ~= "table" then
        logger.warn("GRMTools: Invalid fix record: " .. tostring(path))
        return {}
    end
    return record
end
local cached, cached_at = nil, 0
local function api_catalogue()
    local headers = {["Accept"]="application/vnd.github+json", ["User-Agent"]="GRMTools"}
    local root = "https://api.github.com/repos/skyflarefox/fix/releases/"
    local response = http_client.get(root .. "tags/fix", {headers=headers, timeout=15})
    if not response or response.status ~= 200 then error("Failed to load fixes release (HTTP " .. tostring(response and response.status or "network error") .. ")") end
    local release = utils.decode_json(response.body)
    if not release.id then error("Invalid fixes release") end
    local result, page = {}, 1
    while true do
        local resp = http_client.get(root .. tostring(release.id) .. "/assets?per_page=100&page=" .. page, {headers=headers, timeout=15})
        if not resp or resp.status ~= 200 then error("Failed to load fix assets (HTTP " .. tostring(resp and resp.status or "network error") .. ")") end
        local assets = utils.decode_json(resp.body)
        for _, asset in ipairs(assets) do
            local id, kind = tostring(asset.name or ""):match("^(%d+)_(%a+)%.zip$")
            if id and (kind == "online" or kind == "generic") then
                result[id] = result[id] or {}
                result[id][kind] = asset.browser_download_url
            end
        end
        if #assets < 100 then break end
        page = page + 1
    end
    return result
end
local function public_catalogue()
    local response = http_client.get("https://github.com/skyflarefox/fix/releases/expanded_assets/fix", {
        headers={["Accept"]="text/html", ["User-Agent"]="GRMTools"}, timeout=15
    })
    if not response or response.status ~= 200 then
        error("Failed to load public fix list (HTTP " .. tostring(response and response.status or "network error") .. ")")
    end
    local result = {}
    for path, id, kind in tostring(response.body or ""):gmatch('href="(/skyflarefox/fix/releases/download/fix/(%d+)_(%a+)%.zip)"') do
        if kind == "generic" or kind == "online" then
            result[id] = result[id] or {}
            result[id][kind] = "https://github.com" .. path
        end
    end
    if next(result) == nil then error("The public fix list contains no recognized files") end
    return result
end
local function catalogue()
    if cached and os.time() - cached_at < 300 then return cached end
    local cache_path = paths.backend_path("data/fix_catalogue.json")
    local disk = read_optional_record(cache_path)
    local function valid(value)
        if type(value) ~= "table" or next(value) == nil then return false end
        for id, entry in pairs(value) do
            if not tostring(id):match("^%d+$") or type(entry) ~= "table" then return false end
            for kind, url in pairs(entry) do
                if kind ~= "generic" and kind ~= "online" then return false end
                if url ~= "https://github.com/skyflarefox/fix/releases/download/fix/" .. id .. "_" .. kind .. ".zip" then return false end
            end
        end
        return true
    end
    if valid(disk.entries) and os.time() - (tonumber(disk.fetchedAt) or 0) < 300 then
        cached, cached_at = disk.entries, tonumber(disk.fetchedAt)
        return cached
    end
    local ok, result = pcall(api_catalogue)
    if not ok then
        logger.warn("GRMTools: Fix API unavailable: " .. tostring(result))
        ok, result = pcall(public_catalogue)
    end
    if not ok then
        if valid(disk.entries) then
            logger.warn("GRMTools: Using saved fix catalogue: " .. tostring(result))
            cached, cached_at = disk.entries, os.time()
            return cached
        end
        error(result)
    end
    cached, cached_at = result, os.time()
    pcall(utils.write_json, cache_path, {entries=result, fetchedAt=cached_at})
    return cached
end
function fixes.check_for_fixes(appid)
    local entry = catalogue()[tostring(appid)] or {}
    return {success=true, appid=tonumber(appid), gameName="Unknown Game (" .. tostring(appid) .. ")",
        genericFix={status=entry.generic and 200 or 404, available=entry.generic~=nil, url=entry.generic},
        onlineFix={status=entry.online and 200 or 404, available=entry.online~=nil, url=entry.online}}
end
local function record_root(appid)
    return paths.backend_path("data/fixes/" .. tostring(appid))
end
local function active_kind(appid)
    local record = read_optional_record(fs.join(record_root(appid), "manifest.json"))
    return record.kind or ""
end
function fixes.get_available_fixes()
    local index = catalogue()
    local dir = fs.join(steam_utils.detect_steam_install_path(), "config", "stplug-in")
    local result, seen = {}, {}
    if not fs.exists(dir) then return {success=true, fixes=result} end
    for _, file in ipairs(fs.list(dir) or {}) do
        local name = file.name or ""
        local id = name:match("^(%d+)%.lua$")
        if id and not seen[id] and index[id] then
            seen[id] = true
            local installed = steam_utils.get_game_install_path_response(id)
            if installed.success then
                local applied_kind = active_kind(id)
                for _, kind in ipairs({"generic", "online"}) do
                    if index[id][kind] then
                        table.insert(result, {appid=tonumber(id), gameName="Unknown Game (" .. id .. ")",
                            fixType=kind, downloadUrl=index[id][kind], installPath=installed.installPath, available=true, applied=applied_kind==kind, appliedKind=applied_kind})
                    end
                end
            end
        end
    end
    return {success=true, fixes=result}
end

local function run_operation(appid, kind, operation, url)
    appid = tonumber(appid)
    if not appid or appid < 1 or appid ~= math.floor(appid) or (kind ~= "online" and kind ~= "generic") then
        return {success=false, error="Invalid fix"}
    end
    local installed = steam_utils.get_game_install_path_response(appid)
    if not installed.success then return {success=false, error="Game is not installed"} end
    if m_utils.getenv("OS") ~= "Windows_NT" then return {success=false, error="Fix management requires Windows"} end
    completed_removals[tostring(appid)] = nil
    return engine.run({
        appid=string.format("%.0f", appid),
        kind=kind,
        operation=operation,
        url=url,
        root=installed.installPath,
        records=record_root(appid)
    })
end
function fixes.apply_game_fix(appid, download_url, install_path, fix_type, game_name)
    appid = tonumber(appid)
    if not appid or not steam_utils.has_lua_for_app(appid) then return {success=false, error="Game Lua script not found"} end
    local entry = catalogue()[tostring(appid)] or {}
    local kind = download_url == entry.generic and "generic" or (download_url == entry.online and "online" or nil)
    if not kind then return {success=false, error="Fix not found in source"} end
    if active_kind(appid) ~= "" then return {success=false, error="Remove the applied fix before applying another one"} end
    return run_operation(appid, kind, "apply", download_url)
end
function fixes.uninstall_fix(appid, kind)
    appid = tonumber(appid)
    if not appid then return {success=false, error="Invalid game"} end
    local active = active_kind(appid)
    if active == "" or (kind and kind ~= active) then return {success=false, error="No tracked fix to remove"} end
    return run_operation(appid, active, "remove")
end
function fixes.get_apply_status(appid)
    appid = tonumber(appid)
    if not appid or appid < 1 or appid ~= math.floor(appid) then return {success=false, error="Invalid game"} end
    local key = tostring(appid)
    local directory = record_root(appid)
    local state_path = fs.join(directory, "state.json")
    local state = read_optional_record(state_path)
    if not state.status then
        state = completed_removals[key] or {status="idle", appliedKind=active_kind(appid)}
    end
    if state.status == "done" and state.operation == "remove" and fs.exists(directory) then
        -- Keep the completion result in memory for repeat polls, not on disk.
        -- Never delete backups, journals or unknown files from the status handler.
        local ok, failure = pcall(function()
            if active_kind(appid) ~= "" then error("An applied fix record still exists") end
            for _, entry in ipairs(fs.list(directory) or {}) do
                if entry.name ~= "state.json" then error("Fix files remain in the record directory: " .. tostring(entry.name)) end
            end
            if fs.exists(state_path) and not fs.remove(state_path) then error("Could not remove fix status file") end
            if #fs.list(directory) ~= 0 then error("Fix record directory is not empty") end
            if not fs.remove(directory) then error("Could not remove empty fix record directory") end
        end)
        if not ok then
            return {success=true, state={status="failed", operation="remove", appliedKind="", error="Fix restored, but cleanup failed: " .. tostring(failure)}}
        end
        completed_removals[key] = state
    end
    return {success=true, state=state}
end
return fixes
