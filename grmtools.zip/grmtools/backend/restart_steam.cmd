@echo off
setlocal enableextensions

rem === GRMTools single-file Steam restarter (fully hidden) ===
rem No windows are shown. Uses WMI to launch an independent hidden worker.

for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find "SteamPath"') do set "STEAM_DIR=%%B"
if not defined STEAM_DIR exit /b 1

set "STEAM_EXE=%STEAM_DIR%\Steam.exe"
if not exist "%STEAM_EXE%" exit /b 1

set "WORKER=%TEMP%\grmtools_worker_%RANDOM%.ps1"

rem Write hidden independent worker
> "%WORKER%" echo $ErrorActionPreference = 'Stop'
>> "%WORKER%" echo $log = "$env:TEMP\grmtools_restart.log"
>> "%WORKER%" echo function Log($m) { Add-Content -Path $log -Value "$(Get-Date -Format 'HH:mm:ss') - $m" }
>> "%WORKER%" echo try {
>> "%WORKER%" echo   Log "Worker started"
>> "%WORKER%" echo   Start-Sleep -Seconds 2
>> "%WORKER%" echo   $steam = '%STEAM_EXE%'
>> "%WORKER%" echo   if (-not (Test-Path -LiteralPath $steam)) { Log "Steam.exe missing"; exit 1 }
>> "%WORKER%" echo   Log "Sending -shutdown"
>> "%WORKER%" echo   Start-Process -FilePath $steam -ArgumentList '-shutdown' -WindowStyle Hidden -ErrorAction SilentlyContinue
>> "%WORKER%" echo   $timeout = 25; $elapsed = 0
>> "%WORKER%" echo   while (Get-Process -Name steam -ErrorAction SilentlyContinue) {
>> "%WORKER%" echo     if ($elapsed -ge $timeout) { break }
>> "%WORKER%" echo     Start-Sleep -Milliseconds 500
>> "%WORKER%" echo     $elapsed += 0.5
>> "%WORKER%" echo   }
>> "%WORKER%" echo   if (Get-Process -Name steam -ErrorAction SilentlyContinue) {
>> "%WORKER%" echo     Log "Force killing"
>> "%WORKER%" echo     Stop-Process -Name steam,steamwebhelper -Force -ErrorAction SilentlyContinue
>> "%WORKER%" echo     Start-Sleep -Seconds 1
>> "%WORKER%" echo   }
>> "%WORKER%" echo   try { Set-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name 'StartupModeTmp' -Value 0 -Type DWord -ErrorAction SilentlyContinue } catch {}
>> "%WORKER%" echo   Log "Relaunching"
>> "%WORKER%" echo   Start-Process -FilePath $steam -ArgumentList '-clearbeta' -WindowStyle Normal
>> "%WORKER%" echo   Log "Done"
>> "%WORKER%" echo } catch { Log "ERROR: $_" }
>> "%WORKER%" echo finally { Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue }

rem Launch worker via WMI completely hidden (ShowWindow = 0)
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command ^
  "$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'; " ^
  "$cmd = '\"' + $ps + '\" -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File \"' + '%WORKER%' + '\"'; " ^
  "$wmi = [WMIClass]'\\.\root\cimv2:Win32_Process'; " ^
  "$startup = ([WMIClass]'\\.\root\cimv2:Win32_ProcessStartup').CreateInstance(); " ^
  "$startup.ShowWindow = 0; " ^
  "$r = $wmi.Create($cmd, $null, $startup)"

exit /b 0
