-- LuaTools backend main.lua
-- All exported functions return JSON-encoded strings, mirroring the Python backend's json.dumps() returns.
-- This is required because Millennium's Lua bridge does not deep-serialize nested Lua tables.
local cjson = require("json")
local m_utils = require("utils")
local logger = require("plugin_logger")
local millennium = require("millennium")
local fs = require("fs")
local http_client = require("http_client")
local paths = require("paths")
local steam_utils = require("steam_utils")
local utils = require("plugin_utils")
local locales_mod = require("locales.manager")
local api_manifest = require("api_manifest")
local downloads = require("downloads")
local fixes = require("fixes")
local fix_cleanup = require("fix_cleanup")
local settings_manager = require("settings.manager")
local auto_update = require("auto_update")

-- ── Lua file helpers (depot/manifest/DLC) ────────────────────────────────────
local function get_lua_path(appid)
    local base = steam_utils.detect_steam_install_path()
    if not base or base == "" then return nil end
    local dir = fs.join(base, "config", "stplug-in")
    local p = fs.join(dir, tostring(appid) .. ".lua")
    if fs.exists(p) then return p end
    local pd = fs.join(dir, tostring(appid) .. ".lua.disabled")
    if fs.exists(pd) then return pd end
    return nil
end

local function split_lines(text)
    text = tostring(text or ""):gsub("\r\n", "\n"):gsub("\r", "\n")
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        table.insert(lines, line)
    end
    -- Treat trailing blank lines as file padding so every rewrite stays stable.
    while #lines > 1 and lines[#lines] == "" do
        table.remove(lines)
    end
    return lines
end

local function join_lines(lines)
    return table.concat(lines, "\n")
end

local function parse_lua(text, main_appid)
    local depot_id, manifest_id
    local manifest_count = 0
    local all_manifests_active = true
    local dlcs = {}
    local dlc_map = {}
    local dlc_manifest_seen = {}
    local dlc_manifest_all_commented = {}

    for i, line in ipairs(split_lines(text)) do
        local did, mid = line:match("^%s*set[Mm]anifestid%s*%(%s*(%d+)%s*,%s*[\"']?(%d+)[\"']?")
        local cdid, cmid = line:match("^%s*%-%-%s*set[Mm]anifestid%s*%(%s*(%d+)%s*,%s*[\"']?(%d+)[\"']?")
        if did then
            manifest_count = manifest_count + 1
            if not depot_id then
                depot_id = did
                manifest_id = mid
            end
        elseif cdid then
            manifest_count = manifest_count + 1
            all_manifests_active = false
            if not depot_id then
                depot_id = cdid
                manifest_id = cmid
            end
        end
        local manifest_dlc_id = did or cdid
        if manifest_dlc_id and tonumber(manifest_dlc_id) ~= tonumber(main_appid) then
            local commented = cdid ~= nil
            if not dlc_manifest_seen[manifest_dlc_id] then
                dlc_manifest_seen[manifest_dlc_id] = true
                dlc_manifest_all_commented[manifest_dlc_id] = commented
            else
                dlc_manifest_all_commented[manifest_dlc_id] = dlc_manifest_all_commented[manifest_dlc_id] and commented
            end
        end
        local aid = line:match("^%s*addappid%s*%(%s*(%d+)")
        local caid = line:match("^%s*%-%-%s*addappid%s*%(%s*(%d+)")
        local id = aid or caid
        if id and tonumber(id) ~= tonumber(main_appid) then
            local label = line:match("%)%s*%-%-%s*(.+)$") or ("DLC " .. id)
            label = label:gsub("^%s+", ""):gsub("%s+$", "")
            if not dlc_map[id] then
                dlc_map[id] = { id = id, enabled = aid ~= nil, label = label }
                table.insert(dlcs, dlc_map[id])
            elseif aid then
                dlc_map[id].enabled = true
            end
        end
    end

    for id, dlc in pairs(dlc_map) do
        if dlc_manifest_seen[id] then
            dlc.enabled = dlc_manifest_all_commented[id] == true
        end
    end
    local is_locked = manifest_count > 0 and all_manifests_active

    return {
        depotId = depot_id or "",
        manifestId = manifest_id or "",
        dlcs = dlcs,
        dlcCount = #dlcs,
        isLocked = is_locked
    }
end

local function get_lua_details(appid)
    local path = get_lua_path(appid)
    if not path then return { success = false, error = "Lua file not found" } end
    local info = parse_lua(utils.read_text(path), appid)
    info.success = true
    info.path = path
    info.appid = appid
    return info
end

local function toggle_lua_lock(appid)
    local path = get_lua_path(appid)
    if not path then return { success = false, error = "Lua file not found" } end
    local text = utils.read_text(path)
    local info = parse_lua(text, appid)
    local new_locked = not info.isLocked
    local lines = split_lines(text)

    for i, line in ipairs(lines) do
        local active_indent = line:match("^(%s*)set[Mm]anifestid%s*%(")
        local commented_indent = line:match("^(%s*)%-%-%s*set[Mm]anifestid%s*%(")
        if new_locked and commented_indent then
            local rest = line:sub(#commented_indent + 3):gsub("^%s*", "")
            lines[i] = commented_indent .. rest
        elseif not new_locked and active_indent then
            lines[i] = active_indent .. "-- " .. line:sub(#active_indent + 1)
        end
    end

    utils.write_text(path, join_lines(lines))
    local after = parse_lua(utils.read_text(path), appid)
    return { success = true, isLocked = after.isLocked, depotId = after.depotId, manifestId = after.manifestId }
end

local function set_manifest(appid, depot_id, manifest_id)
    local path = get_lua_path(appid)
    if not path then return { success = false, error = "file not found" } end
    depot_id = tostring(depot_id or ""):gsub("%s", "")
    manifest_id = tostring(manifest_id or ""):gsub("%s", "")
    if not depot_id:match("^%d+$") or not manifest_id:match("^%d+$") then
        return { success = false, error = "invalid values" }
    end
    local text = utils.read_text(path)
    local lines = split_lines(text)
    local changed = false
    local found = false

    for i, line in ipairs(lines) do
        local indent, rest = line:match("^(%s*)(%-%-?%s*set[Mm]anifestid%s*%(.*)$")
        if not indent then
            indent, rest = line:match("^(%s*)(set[Mm]anifestid%s*%(.*)$")
        end
        if rest then
            local current = rest:match("set[Mm]anifestid%s*%(%s*(%d+)")
            if current then
                found = true
                local is_commented = rest:match("^%-%-") ~= nil
                local prefix = is_commented and "-- " or ""
                local new_line = indent .. prefix .. string.format('setManifestid(%s, "%s")', depot_id, manifest_id)
                if new_line ~= line then
                    lines[i] = new_line
                    changed = true
                end
                break
            end
        end
    end

    if not found then
        table.insert(lines, string.format('setManifestid(%s, "%s")', depot_id, manifest_id))
        changed = true
    end

    if changed then
        utils.write_text(path, join_lines(lines))
    end
    return { success = true, changed = changed }
end

local function set_dlc_enabled(appid, dlc_id, want_enabled)
    local path = get_lua_path(appid)
    if not path then return { success = false, error = "Lua file not found" } end
    dlc_id = tostring(dlc_id or "")
    if not dlc_id:match("^%d+$") then return { success = false, error = "invalid dlc id" } end
    local lines = split_lines(utils.read_text(path))
    local changed = false
    local has_manifest = false

    for i, line in ipairs(lines) do
        local active_indent = line:match("^(%s*)set[Mm]anifestid%s*%(%s*" .. dlc_id .. "%s*,")
        local commented_indent = line:match("^(%s*)%-%-%s*set[Mm]anifestid%s*%(%s*" .. dlc_id .. "%s*,")
        if active_indent or commented_indent then has_manifest = true end
        if not want_enabled and commented_indent then
            local rest = line:sub(#commented_indent + 3):gsub("^%s*", "")
            lines[i] = commented_indent .. rest
            changed = true
        elseif want_enabled and active_indent then
            lines[i] = active_indent .. "-- " .. line:sub(#active_indent + 1)
            changed = true
        end
    end

    if not has_manifest then
        for i, line in ipairs(lines) do
            local active_addappid = line:match("^(%s*)addappid%s*%(%s*" .. dlc_id .. "%s*[,)]")
            local commented_addappid = line:match("^(%s*)%-%-%s*addappid%s*%(%s*" .. dlc_id .. "%s*[,)]")
            if want_enabled and commented_addappid then
                lines[i] = commented_addappid .. line:sub(#commented_addappid + 3):gsub("^%s*", "")
                changed = true
            elseif not want_enabled and active_addappid then
                lines[i] = active_addappid .. "-- " .. line:sub(#active_addappid + 1)
                changed = true
            end
        end
    end
    if changed then utils.write_text(path, join_lines(lines)) end
    return { success = true, changed = changed, dlcId = dlc_id, enabled = want_enabled }
end

-- ── Helpers ──────────────────────────────────────────────────────────────────
--- Safely encode a Lua table to a JSON string (same as Python json.dumps).
local function json_ok(data)
    local ok, s = pcall(cjson.encode, data)
    if ok then return s end
    logger.warn("json_ok encode failed: " .. tostring(s))
    return '{"success":false,"error":"serialization error"}'
end

local function json_err(msg)
    return json_ok({ success = false, error = tostring(msg) })
end

-- ── Lifecycle ────────────────────────────────────────────────────────────────
-- Millennium 3.x injects .millennium/Dist/webkit.js automatically.
-- Do NOT copy files to steamui/webkit or call add_browser_js / add_browser_css.
local function on_load()
    logger.log("Bootstrapping LuaTools plugin, millennium " .. millennium.version())
    steam_utils.detect_steam_install_path()
    utils.ensure_temp_download_dir()
    local ok_s, err_s = pcall(settings_manager.init_settings)
    if not ok_s then logger.warn("settings init failed: " .. tostring(err_s)) end
    local ok_u, upd_msg = pcall(auto_update.apply_pending_update_if_any)
    if ok_u and upd_msg and upd_msg ~= "" then
        api_manifest.store_last_message(upd_msg)
    end
    fix_cleanup.sweep()
    api_manifest.init_apis()
    millennium.ready()
end

local function on_unload()
    logger.log("unloading LuaTools plugin")
end

local function on_frontend_loaded()
end

-- ── Logger (called as "Logger.log" from JS) ──────────────────────────────────
Logger = {}
function Logger.log(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.log("[Frontend] " .. msg)
    return json_ok({ success = true })
end
function Logger.warn(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.warn("[Frontend] " .. msg)
    return json_ok({ success = true })
end
function Logger.error(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.error("[Frontend] " .. msg)
    return json_ok({ success = true })
end
_G["Logger.log"] = Logger.log
_G["Logger.warn"] = Logger.warn
_G["Logger.error"] = Logger.error

-- ── Exported API Methods ─────────────────────────────────────────────────────
function GetPluginDir()
    return paths.get_plugin_dir()
end
function InitApis()
    local ok, res = pcall(api_manifest.init_apis)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function GetInitApisMessage()
    local ok, res = pcall(api_manifest.get_init_apis_message)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function FetchFreeApisNow()
    local ok, res = pcall(api_manifest.fetch_free_apis_now)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function CheckForUpdatesNow()
    local ok, res = pcall(auto_update.check_for_updates_now)
    if not ok then
        logger.warn("CheckForUpdatesNow failed: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end
function RestartSteam()
    local ok, success = pcall(auto_update.restart_steam)
    if ok and success then
        return json_ok({ success = true })
    end
    return json_ok({ success = false, error = "Failed to restart Steam" })
end
function HasLuaToolsForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, exists = pcall(steam_utils.has_lua_for_app, tonumber(appid))
    if not ok then return json_err(exists) end
    return json_ok({ success = true, exists = exists == true })
end
function StartAddViaLuaTools(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.start_add_via_luatools, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function GetAddViaLuaToolsStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.get_add_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function GetApiList()
    local ok, res = pcall(api_manifest.get_api_list)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function AddCustomApi(api_key, contentScriptQuery, name, url)
    local payload = {
        name = tostring(name or ""),
        url = tostring(url or ""),
        api_key = tostring(api_key or "")
    }
    local ok, res = pcall(api_manifest.add_custom_api, payload)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function GetAllApis()
    local ok, res = pcall(api_manifest.get_all_apis)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function ToggleApi(params, contentScriptQuery)
    local apiName = params
    if type(params) == "table" then apiName = params.apiName or params.name end
    local ok, res = pcall(api_manifest.toggle_api, tostring(apiName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function RemoveApi(params, contentScriptQuery)
    local apiName = params
    if type(params) == "table" then apiName = params.apiName or params.name end
    local ok, res = pcall(api_manifest.remove_api, tostring(apiName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function RenameApi(params, contentScriptQuery)
    local old_name, new_name
    if type(params) == "table" then
        new_name = params.new_name
        old_name = params.old_name or params.apiName or params.name
    else
        old_name = params
    end
    local ok, res = pcall(api_manifest.rename_api, tostring(old_name or ""), tostring(new_name or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function ReorderApis(params, contentScriptQuery)
    local names = params
    if type(params) == "table" and params.apiNames then
        names = params.apiNames
    end
    if type(names) == "string" then
        local ok, parsed = pcall(cjson.decode, names)
        if ok and type(parsed) == "table" then
            names = parsed
        end
    end
    if type(names) ~= "table" then
        return json_ok({ success = false, error = "Invalid argument, got type: " .. type(names) })
    end
    local ok, res = pcall(api_manifest.set_api_order, names)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function CancelAddViaLuaTools(appid)
    return json_ok({ success = true })
end
function CheckApisForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.check_apis_for_app, tonumber(appid))
    if not ok then return json_err(res) end
    if res and type(res.results) == "table" and #res.results == 0 then
        local success_json = res.success and "true" or "false"
        return '{"success":' .. success_json .. ',"results":[]}'
    end
    return json_ok(res)
end
function GetMorrenusStats(api_key, force_refresh)
    if type(api_key) == "table" then
        force_refresh = api_key.force_refresh
        api_key = api_key.api_key
    end
    api_key = tostring(api_key or "")
    if api_key == "" then return json_err("api_key required") end
    local endpoint = "https://hubcapmanifest.com/api/v1/user/stats?api_key=" .. api_key
    local ok, resp = pcall(http_client.get, endpoint, { timeout = 10 })
    if ok and resp and resp.status == 200 then
        return resp.body
    end
    return json_err("request failed")
end
function StartAddViaLuaToolsFromUrl(apiName, appid, contentScriptQuery, url)
    local ok, res = pcall(downloads.start_add_via_luatools_from_url, appid, url, apiName)
    if not ok then
        logger.warn("StartAddViaLuaToolsFromUrl CRASHED inside pcall: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end
function GetIconDataUrl()
    local icon_path = fs.join(paths.get_plugin_dir(), "public", "luatools-icon.png")
    if fs.exists(icon_path) then
        local content = m_utils.read_file(icon_path)
        if content then
            return json_ok({ success = true, dataUrl = "data:image/png;base64," ..
            (m_utils.base64_encode and m_utils.base64_encode(content) or "") })
        end
    end
    return json_ok({ success = false, error = "icon not found" })
end
function GetGamesDatabase()
    local ok, res = pcall(function()
        local db_path = paths.backend_path("data/applist.json")
        if fs.exists(db_path) then
            local data = utils.read_json(db_path)
            return { success = true, apps = data.apps or data or {} }
        end
        return { success = true, apps = {} }
    end)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function ReadLoadedApps()
    local ok, res = pcall(function()
        local log_path = paths.backend_path("loadedappids.txt")
        local apps = {}
        if fs.exists(log_path) then
            local text = utils.read_text(log_path)
            for line in (text .. "\n"):gmatch("([^\n]*)\n") do
                local appid = tonumber(line:match("^%s*(%d+)%s*$"))
                if appid then table.insert(apps, appid) end
            end
        end
        return { success = true, apps = apps }
    end)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function DismissLoadedApps()
    local ok, err = pcall(function()
        local log_path = paths.backend_path("loadedappids.txt")
        if fs.exists(log_path) then
            m_utils.write_file(log_path, "")
        end
    end)
    if not ok then return json_err(err) end
    return json_ok({ success = true })
end
function DeleteLuaToolsForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local base = steam_utils.detect_steam_install_path()
   
    local stplugin_dir = fs.join(base, "config", "stplug-in")
    local lua_dir = fs.join(base, "config", "lua")
   
    local candidates = {
        fs.join(stplugin_dir, tostring(appid) .. ".lua"),
        fs.join(stplugin_dir, tostring(appid) .. ".lua.disabled"),
        fs.join(lua_dir, tostring(appid) .. ".lua"),
        fs.join(lua_dir, tostring(appid) .. ".lua.disabled"),
    }
   
    local deleted = {}
    for _, p in ipairs(candidates) do
        if fs.exists(p) then
            pcall(fs.remove, p)
            table.insert(deleted, p)
        end
    end
    return json_ok({ success = true, deleted = deleted, count = #deleted })
end
function CheckForFixes(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.check_for_fixes, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function ApplyGameFix(appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath)
    if type(appid) == "table" then
        local params = appid
        appid = params.appid
        downloadUrl = params.downloadUrl
        fixType = params.fixType
        gameName = params.gameName
        installPath = params.installPath
    end
    local ok, res = pcall(fixes.apply_game_fix,
        tonumber(appid), tostring(downloadUrl or ""),
        tostring(installPath or ""), tostring(fixType or ""), tostring(gameName or ""))
    if not ok then
        logger.warn("ApplyGameFix CRASHED: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end
function GetApplyFixStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.get_apply_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function CancelApplyFix(appid)
    return json_ok({ success = true })
end
function UninstallFix(appid, contentScriptQuery, fixType)
    if type(appid) == "table" then
        fixType = appid.fixType
        appid = appid.appid
    elseif fixType == nil and (contentScriptQuery == "generic" or contentScriptQuery == "online") then
        fixType = contentScriptQuery
    end
    local ok, res = pcall(fixes.uninstall_fix, tonumber(appid), fixType)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function UnFixGame(appid, installPath, fixDate)
    if type(appid) == "table" then
        installPath = appid.installPath; fixDate = appid.fixDate; appid = appid.appid
    end
    return json_ok({ success = false, error = "Not yet implemented" })
end
function GetUnfixStatus(appid)
    return json_ok({ success = true, state = { status = "done" } })
end
function CleanupUninstalledFixes()
    return json_ok(fix_cleanup.sweep())
end
function GetInstalledFixes()
    fix_cleanup.sweep()
    local ok, result = pcall(fixes.get_available_fixes)
    if not ok then
        logger.warn("GetInstalledFixes failed: " .. tostring(result))
        return json_err(result)
    end
    return json_ok(result)
end
function GetInstalledLuaScripts()
    fix_cleanup.sweep()
    local ok, res = pcall(function()
        local base = steam_utils.detect_steam_install_path()
        local target_dir = fs.join(base, "config", "stplug-in")
        local added_dates = utils.read_json(paths.backend_path("data/game_added_dates.json"))
        local scripts = {}
        local ok2, files = pcall(fs.list, target_dir)
        if ok2 and files then
            for _, entry in ipairs(files) do
                local name = entry.name or ""
                if name:match("%.lua$") or name:match("%.lua%.disabled$") then
                    local aid = name:match("^(%d+)%.")
                    if aid then
                        local details = get_lua_details(tonumber(aid))
                        local installation = steam_utils.get_game_install_path_response(aid)
                        local game_name = installation.gameName
                        if not game_name or game_name == "" then
                            local text = utils.read_text(fs.join(target_dir, name))
                            for line in text:gmatch("[^\r\n]+") do
                                if line:match("^%s*addappid%s*%(%s*" .. aid .. "%s*[,)]")
                                    or line:match("^%s*%-%-%s*addappid%s*%(%s*" .. aid .. "%s*[,)]") then
                                    game_name = line:match("%)%s*%-%-%s*(.+)$")
                                    if game_name then game_name = game_name:gsub("%s+$", "") end
                                    break
                                end
                            end
                        end
                        table.insert(scripts, {
                            appid = tonumber(aid),
                            gameName = game_name or ("Unknown Game (" .. aid .. ")"),
                            filename = name,
                            isDisabled = name:match("%.disabled$") ~= nil,
                            addedAt = tonumber(added_dates[aid]) or 0,
                            isInstalled = installation.success == true,
                            path = entry.path or fs.join(target_dir, name),
                            dlcCount = details.dlcCount or 0,
                            isLocked = details.isLocked or false,
                            depotId = details.depotId or "",
                            manifestId = details.manifestId or ""
                        })
                    end
                end
            end
        end
        return { success = true, scripts = scripts }
    end)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetLuaDetails(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(get_lua_details, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ToggleLuaLock(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(toggle_lua_lock, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function SetManifest(appid, depotId, manifestId)
    if type(appid) == "table" then
        depotId = appid.depotId
        manifestId = appid.manifestId
        appid = appid.appid
    end
    local ok, res = pcall(set_manifest, tonumber(appid), tostring(depotId or ""), tostring(manifestId or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function SetDlcEnabled(appid, dlcId, enabled)
    if type(appid) == "table" then
        dlcId = appid.dlcId
        enabled = appid.enabled
        appid = appid.appid
    end
    appid = tonumber(appid)
    dlcId = tostring(dlcId or "")
    local want = (enabled == true or enabled == "true" or enabled == 1 or enabled == "1")
    local ok, res = pcall(set_dlc_enabled, appid, dlcId, want)
    if not ok then return json_err(res) end
    return json_ok(res)
end
function GetGameInstallPath(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(steam_utils.get_game_install_path_response, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end
function OpenGameFolder(path)
    if type(path) == "table" then path = path.path end
    local ok, success = pcall(steam_utils.open_game_folder, tostring(path or ""))
    if ok and success then
        return json_ok({ success = true })
    end
    return json_ok({ success = false, error = "Failed to open path" })
end
function OpenExternalUrl(url)
    if type(url) == "table" then url = url.url end
    url = tostring(url or "")
    if not (url:match("^https?://[%w%.%-]+") and not url:find("[%c\"']")) then
        return json_err("Invalid URL")
    end
    local is_win = (m_utils.getenv("OS") or ""):find("Windows") ~= nil
    -- m_utils.exec runs commands through cmd.exe on Windows. Use cmd's `start`
    -- builtin so the URL is handed to the user's registered default browser.
    local command = is_win
        and ('start "" "' .. url .. '"')
        or ('xdg-open "' .. url .. '"')
    local ok, output, exit_code = pcall(m_utils.exec, command)
    if not ok then
        logger.warn("OpenExternalUrl failed to launch browser: " .. tostring(output))
        return json_err("Failed to open URL")
    end
    if tonumber(exit_code) ~= 0 then
        logger.warn("OpenExternalUrl command exited with " .. tostring(exit_code) .. ": " .. tostring(output or ""))
        return json_err("Failed to open URL")
    end
    return json_ok({ success = true })
end
function GetSettingsConfig(params)
    if type(params) ~= "table" then params = {} end
    local ok, payload = pcall(settings_manager.get_settings_payload, params.steamLanguage)
    if not ok then
        logger.warn("GetSettingsConfig failed: " .. tostring(payload))
        return json_err(payload)
    end
    return json_ok({
        success = true,
        schemaVersion = payload.version,
        schema = payload.schema or {},
        values = payload.values or {},
        language = payload.language,
        locales = payload.locales or {},
        translations = payload.translations or {}
    })
end
function GetThemes()
    local themes_json_path = fs.join(paths.get_plugin_dir(), "public", "themes", "themes.json")
    local themes_array = {}
    if fs.exists(themes_json_path) then
        local success, data = pcall(cjson.decode, utils.read_text(themes_json_path))
        if success and type(data) == "table" then
            themes_array = data
        else
            logger.warn("GetThemes failed to decode themes.json")
        end
    else
        logger.warn("GetThemes: themes.json not found")
    end
    return json_ok({ success = true, themes = themes_array })
end
function ApplySettingsChanges(changes)
    local payload = nil
    local steam_language = type(changes) == "table" and changes.steamLanguage or nil
    if type(changes) == "string" and changes ~= "" then
        local ok, decoded = pcall(cjson.decode, changes)
        if not ok then
            logger.warn("ApplySettingsChanges: failed to parse changes string")
            return json_err("Invalid JSON payload")
        end
        if type(decoded) == "table" and decoded.changes then
            payload = decoded.changes
        elseif type(decoded) == "table" and type(decoded.changesJson) == "string" then
            local ok2, inner = pcall(cjson.decode, decoded.changesJson)
            if ok2 then payload = inner else return json_err("Invalid JSON payload") end
        else
            payload = decoded
        end
    elseif type(changes) == "table" then
        if changes.changes then
            payload = changes.changes
        elseif type(changes.changesJson) == "string" then
            local ok2, inner = pcall(cjson.decode, changes.changesJson)
            if ok2 then payload = inner else return json_err("Invalid JSON payload") end
        else
            payload = changes
        end
    else
        payload = {}
    end
    if type(payload) ~= "table" then
        logger.warn("ApplySettingsChanges: payload is not a table: " .. tostring(payload))
        return json_err("Invalid payload format")
    end
    local ok, res = pcall(settings_manager.apply_settings_changes, payload, steam_language)
    if not ok then
        logger.warn("ApplySettingsChanges failed: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end
function GetAvailableLocales()
    local ok, locs = pcall(settings_manager.get_available_locales)
    if not ok then return json_err(locs) end
    return json_ok({ success = true, locales = locs })
end
function SetSteamLanguage(params)
    if type(params) == "table" then
        params = params.language or params.lang
    end
    local ok, language = pcall(settings_manager.set_steam_language, tostring(params or ""))
    if not ok then return json_err(language) end
    return json_ok({ success = true, language = language })
end
function GetTranslations(language)
    if type(language) == "table" then
        language = language.language or language.lang
    end
    local ok_settings, settings = pcall(settings_manager.get_settings_state)
    local general = ok_settings and settings.values and settings.values.general or {}
    if general.useSteamLanguage ~= false then
        language = settings_manager.get_current_language(language)
    elseif not language or language == "" then
        language = general.language or locales_mod.DEFAULT_LOCALE
    end
    language = tostring(language or locales_mod.DEFAULT_LOCALE)
    local ok, strings = pcall(function()
        return locales_mod.get_locale_manager():get_locale_strings(language)
    end)
    if not ok then
        logger.warn("GetTranslations failed: " .. tostring(strings))
        return json_err(strings)
    end
    local ok2, locs = pcall(settings_manager.get_available_locales)
    return json_ok({
        success = true,
        strings = strings or {},
        language = language,
        locales = ok2 and locs or {}
    })
end
function GetAvailableThemes()
    return json_ok({ success = true, themes = {} })
end

-- ── Return lifecycle table ────────────────────────────────────────────────────
return {
    on_load = on_load,
    on_unload = on_unload,
    on_frontend_loaded = on_frontend_loaded,
}
