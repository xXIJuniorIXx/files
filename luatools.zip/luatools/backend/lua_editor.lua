-- LuaTools lua file editor: parse depot/manifest/DLCs and lock against updates
local fs = require("fs")
local steam_utils = require("steam_utils")
local utils = require("plugin_utils")
local logger = require("plugin_logger")

local M = {}

local function get_lua_path(appid)
    local base = steam_utils.detect_steam_install_path()
    if not base or base == "" then return nil end
    local dir = fs.join(base, "config", "stplug-in")
    local p = fs.join(dir, tostring(appid) .. ".lua")
    if fs.exists(p) then return p end
    local pd = fs.join(dir, tostring(appid) .. ".lua.disabled")
    if fs.exists(pd) then return pd end
    return nil
end

local function split_lines(text)
    text = tostring(text or ""):gsub("\r\n", "\n"):gsub("\r", "\n")
    local lines = {}
    for line in (text .. "\n"):gmatch("(.-)\n") do
        table.insert(lines, line)
    end
    -- Treat trailing blank lines as file padding so every rewrite stays stable.
    while #lines > 1 and lines[#lines] == "" do
        table.remove(lines)
    end
    return lines
end

local function join_lines(lines)
    return table.concat(lines, "\n")
end

local function parse_lua(text, main_appid)
    local lines = split_lines(text)
    local depot_id, manifest_id
    local manifest_count = 0
    local all_manifests_active = true
    local dlcs = {}
    local dlc_map = {}
    local dlc_manifest_seen = {}
    local dlc_manifest_all_commented = {}

    for i, line in ipairs(lines) do
        local did, mid = line:match("^%s*set[Mm]anifestid%s*%(%s*(%d+)%s*,%s*[\"']?(%d+)[\"']?")
        local cdid, cmid = line:match("^%s*%-%-%s*set[Mm]anifestid%s*%(%s*(%d+)%s*,%s*[\"']?(%d+)[\"']?")
        if did then
            manifest_count = manifest_count + 1
            if not depot_id then
                depot_id = did
                manifest_id = mid
            end
        elseif cdid then
            manifest_count = manifest_count + 1
            all_manifests_active = false
            if not depot_id then
                depot_id = cdid
                manifest_id = cmid
            end
        end
        local manifest_dlc_id = did or cdid
        if manifest_dlc_id and tonumber(manifest_dlc_id) ~= tonumber(main_appid) then
            local commented = cdid ~= nil
            if not dlc_manifest_seen[manifest_dlc_id] then
                dlc_manifest_seen[manifest_dlc_id] = true
                dlc_manifest_all_commented[manifest_dlc_id] = commented
            else
                dlc_manifest_all_commented[manifest_dlc_id] = dlc_manifest_all_commented[manifest_dlc_id] and commented
            end
        end
        local aid = line:match("^%s*addappid%s*%(%s*(%d+)")
        local caid = line:match("^%s*%-%-%s*addappid%s*%(%s*(%d+)")
        local id = aid or caid
        if id and tonumber(id) ~= tonumber(main_appid) then
            local label = line:match("%)%s*%-%-%s*(.+)$") or ("DLC " .. id)
            label = label:gsub("^%s+", ""):gsub("%s+$", "")
            if not dlc_map[id] then
                dlc_map[id] = { id = id, enabled = aid ~= nil, label = label, lineIndexes = { i } }
                table.insert(dlcs, dlc_map[id])
            else
                table.insert(dlc_map[id].lineIndexes, i)
                if aid then dlc_map[id].enabled = true end
            end
        end
    end

    for id, dlc in pairs(dlc_map) do
        if dlc_manifest_seen[id] then
            dlc.enabled = dlc_manifest_all_commented[id] == true
        end
    end
    local is_locked = manifest_count > 0 and all_manifests_active

    return {
        depotId = depot_id or "",
        manifestId = manifest_id or "",
        dlcs = dlcs,
        dlcCount = #dlcs,
        isLocked = is_locked,
        dlcMap = dlc_map
    }
end

function M.get_details(appid)
    local path = get_lua_path(appid)
    if not path then
        return { success = false, error = "Lua file not found" }
    end
    local text = utils.read_text(path)
    local info = parse_lua(text, appid)
    info.success = true
    info.path = path
    info.appid = appid
    info.dlcMap = nil
    return info
end

function M.toggle_lock(appid)
    local path = get_lua_path(appid)
    if not path then
        return { success = false, error = "Lua file not found" }
    end
    local text = utils.read_text(path)
    local info = parse_lua(text, appid)
    local new_locked = not info.isLocked
    local lines = split_lines(text)

    for i, line in ipairs(lines) do
        local active_indent = line:match("^(%s*)set[Mm]anifestid%s*%(")
        local commented_indent = line:match("^(%s*)%-%-%s*set[Mm]anifestid%s*%(")
        if new_locked and commented_indent then
            local rest = line:sub(#commented_indent + 3):gsub("^%s*", "")
            lines[i] = commented_indent .. rest
        elseif not new_locked and active_indent then
            lines[i] = active_indent .. "-- " .. line:sub(#active_indent + 1)
        end
    end

    utils.write_text(path, join_lines(lines))
    local after = parse_lua(utils.read_text(path), appid)
    return {
        success = true,
        isLocked = after.isLocked,
        depotId = after.depotId,
        manifestId = after.manifestId
    }
end

function M.set_dlc_enabled(appid, dlc_id, want_enabled)
    local path = get_lua_path(appid)
    if not path then
        return { success = false, error = "Lua file not found" }
    end
    dlc_id = tostring(dlc_id or "")
    if not dlc_id:match("^%d+$") then
        return { success = false, error = "invalid dlc id" }
    end
    local lines = split_lines(utils.read_text(path))
    local changed = false
    local has_manifest = false
    local matched = 0

    for i, line in ipairs(lines) do
        local active_indent = line:match("^(%s*)set[Mm]anifestid%s*%(%s*" .. dlc_id .. "%s*,")
        local commented_indent = line:match("^(%s*)%-%-%s*set[Mm]anifestid%s*%(%s*" .. dlc_id .. "%s*,")
        if active_indent or commented_indent then
            matched = matched + 1
            if active_indent or commented_indent then has_manifest = true end
        if not want_enabled and commented_indent then
                local rest = line:sub(#commented_indent + 3):gsub("^%s*", "")
                lines[i] = commented_indent .. rest
                changed = true
            elseif want_enabled and active_indent then
                lines[i] = active_indent .. "-- " .. line:sub(#active_indent + 1)
                changed = true
            end
        end
    end

    logger.log("set_dlc_enabled id=" .. dlc_id .. " matched=" .. matched .. " changed=" .. tostring(changed))
    if not has_manifest then
        for i, line in ipairs(lines) do
            local active_addappid = line:match("^(%s*)addappid%s*%(%s*" .. dlc_id .. "%s*[,)]")
            local commented_addappid = line:match("^(%s*)%-%-%s*addappid%s*%(%s*" .. dlc_id .. "%s*[,)]")
            if want_enabled and commented_addappid then
                lines[i] = commented_addappid .. line:sub(#commented_addappid + 3):gsub("^%s*", "")
                changed = true
            elseif not want_enabled and active_addappid then
                lines[i] = active_addappid .. "-- " .. line:sub(#active_addappid + 1)
                changed = true
            end
        end
    end
    if changed then utils.write_text(path, join_lines(lines)) end
    return { success = true, changed = changed, dlcId = dlc_id, enabled = want_enabled, matched = matched }
end
function M.save_config(appid, depot_id, manifest_id, dlcs)
    -- Kept for compatibility; DLC toggles now go through set_dlc_enabled
    return { success = true }
end

return M
