-- Fix application/removal controlled by Lua. No PowerShell or FFI.
-- Keep original files until restoration succeeds, then remove backup/work files.
local fs = require("fs")
local native = require("utils")
local json = require("json")
local engine = {}
local running = {}

local function checked(value, err)
    if value == nil or value == false then error(tostring(err or "File operation failed"), 0) end
    return value
end
local function mkdir(path)
    if not fs.exists(path) then checked(fs.create_directories(path)) end
    if not fs.is_directory(path) then error("Expected a directory: " .. path, 0) end
end
local function normal(path)
    return checked(fs.absolute(path)):gsub("\\", "/"):gsub("/+$", "")
end
local function same(a, b) return normal(a):lower() == normal(b):lower() end
local function inside(root, path)
    root, path = normal(root):lower(), normal(path):lower()
    return path == root or path:sub(1, #root + 1) == root .. "/"
end
local function safe(root, relative)
    if type(relative) ~= "string" or relative == "" or relative:find('[%c<>:"|?*]') then error("Invalid fix path", 0) end
    relative = relative:gsub("\\", "/")
    if relative:sub(1, 1) == "/" or relative:find("//", 1, true) or relative:sub(-1) == "/" then error("Invalid fix path", 0) end
    local parts = {}
    for part in relative:gmatch("[^/]+") do
        local device = part:match("^[^%.]+") or part
        device = device:upper()
        if part == "." or part == ".." or part:match("[%. ]$") or device == "CON" or device == "PRN" or device == "AUX" or device == "NUL" or device:match("^COM%d$") or device:match("^LPT%d$") then error("Unsafe fix path: " .. relative, 0) end
        parts[#parts + 1] = part
    end
    if fs.is_symlink(root) then error("Linked game/record roots are not supported", 0) end
    local canonical_root = fs.exists(root) and checked(fs.canonical(root)) or normal(root)
    local current = root
    for _, part in ipairs(parts) do
        current = fs.join(current, part)
        if fs.exists(current) then
            if fs.is_symlink(current) or not inside(canonical_root, checked(fs.canonical(current))) then error("Linked path outside target directory", 0) end
        end
    end
    if not inside(root, current) then error("Path outside target directory", 0) end
    return current
end
local function quote(value)
    value = tostring(value)
    -- cmd.exe expands percent/exclamation expressions even inside quotes.
    if value:find('[%c"%%!]') then error("Unsupported characters in command argument", 0) end
    return '"' .. value .. '"'
end
local function command(value)
    local output, status = native.exec(value)
    if type(output) ~= "string" or tonumber(status) ~= 0 then error("Command failed: " .. tostring(output or status), 0) end
    return output
end
local function hash(path)
    if not fs.exists(path) then return nil end
    if not fs.is_file(path) then error("Expected a regular file: " .. path, 0) end
    -- certutil rejects zero-byte files; their standard SHA-256 is constant.
    if checked(fs.file_size(path)) == 0 then return "E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855" end
    local output = command("certutil.exe -hashfile " .. quote(path) .. " SHA256 2>&1")
    for line in output:gmatch("[^\r\n]+") do
        local value = line:gsub("%s", "")
        if #value == 64 and value:match("^%x+$") then return value:upper() end
    end
    error("Unable to calculate SHA-256: " .. path, 0)
end
local function copy(source, target)
    mkdir(fs.parent_path(target))
    checked(fs.copy(source, target, false))
end
local function remove(path)
    if fs.exists(path) then checked(fs.remove(path)) end
end
local function read_record(path)
    if not fs.exists(path) then return nil end
    local data = checked(native.read_file(path))
    local ok, result = pcall(json.decode, data)
    if not ok or type(result) ~= "table" then error("Invalid fix record: " .. path, 0) end
    return result
end
local function write_record(path, value)
    mkdir(fs.parent_path(path))
    local text = json.encode(value)
    local temp = path .. ".tmp"
    checked(native.write_file(temp, text))
    if native.read_file(temp) ~= text then error("Failed to verify fix record", 0) end
    checked(fs.rename(temp, path))
end
local function wipe_work(root, relative)
    local path = safe(root, relative)
    if fs.exists(path) then checked(fs.remove_all(path)) end
end
local function valid_hash(value) return type(value) == "string" and #value == 64 and value:match("^%x+$") end
local function validate_record(record, root, kind)
    if type(record) ~= "table" or type(record.root) ~= "string" or not same(record.root, root) or record.kind ~= kind or type(record.files) ~= "table" or #record.files == 0 then error("Fix record does not match this game", 0) end
    local seen = {}
    for _, entry in ipairs(record.files) do
        safe(root, entry.path)
        local key = entry.path:gsub("\\", "/"):lower()
        if seen[key] or not valid_hash(entry.hash) or (entry.originalHash and not valid_hash(entry.originalHash)) then error("Invalid tracked fix file", 0) end
        seen[key] = true
        entry.hash = entry.hash:upper()
        if entry.originalHash then entry.originalHash = entry.originalHash:upper() end
    end
end

local function restore(root, records, record, allow_original)
    validate_record(record, root, record.kind)
    local backup_root = safe(records, "backup")
    local work_name = "restore-" .. native.uuid()
    local work = safe(records, work_name)
    mkdir(work)
    local changes, touched = {}, {}
    local ok, err = pcall(function()
        -- Validate every original before changing any game file.
        for _, entry in ipairs(record.files) do
            local target = safe(root, entry.path)
            local current = hash(target)
            local original_hash, backup
            if entry.original then
                backup = safe(backup_root, entry.path)
                original_hash = hash(backup)
                if not original_hash or (entry.originalHash and original_hash ~= entry.originalHash) then
                    error("Original file backup is missing or changed: " .. entry.path, 0)
                end
            end
            -- Recovery may encounter files already restored by an earlier attempt.
            local already_restored = current == original_hash
            if current and current ~= entry.hash and not already_restored then
                error("File changed since fix application: " .. entry.path, 0)
            end
            local snapshot = safe(work, entry.path)
            if current then
                copy(target, snapshot)
                if hash(snapshot) ~= current then error("File changed while preparing removal", 0) end
            end
            changes[#changes + 1] = {target=target, snapshot=snapshot, before=current, after=original_hash, backup=backup, entry=entry}
        end
    end)
    if not ok then pcall(wipe_work, records, work_name); error(err, 0) end
    write_record(fs.join(records, "removing.json"), record)
    ok, err = pcall(function()
        for _, change in ipairs(changes) do
            if hash(change.target) ~= change.before then error("File changed during removal: " .. change.entry.path, 0) end
            touched[#touched + 1] = change
            if change.backup then copy(change.backup, change.target) else remove(change.target) end
            if hash(change.target) ~= change.after then error("Restoration verification failed: " .. change.entry.path, 0) end
        end
    end)
    if not ok then
        local errors = {}
        for i = #touched, 1, -1 do
            local change = touched[i]
            local restored, failure = pcall(function()
                local current = hash(change.target)
                if current ~= change.after and current ~= change.before then error("A later change was preserved: " .. change.entry.path, 0) end
                if change.before then copy(change.snapshot, change.target) else remove(change.target) end
                if hash(change.target) ~= change.before then error("Removal rollback verification failed", 0) end
            end)
            if not restored then errors[#errors + 1] = tostring(failure) end
        end
        if #errors == 0 then pcall(wipe_work, records, work_name) end
        error(tostring(err) .. (#errors > 0 and ("; recovery files preserved: " .. table.concat(errors, "; ")) or ""), 0)
    end
    -- All originals are verified at their original locations. Only now discard
    -- the payload backups and temporary snapshots. Keep metadata until cleanup
    -- succeeds so a failed cleanup can be retried without a false success.
    wipe_work(records, work_name)
    wipe_work(records, "backup")
    remove(fs.join(records, "pending.json"))
    remove(fs.join(records, "removing.json"))
    remove(fs.join(records, "manifest.json"))
end

local function unpack_archive(zip, records, work_name)
    local stage = safe(records, work_name)
    mkdir(stage)
    local names = {}
    local listing = command("tar.exe -tf " .. quote(zip) .. " 2>&1")
    for relative in listing:gmatch("[^\r\n]+") do
        relative = relative:gsub("\\", "/"):gsub("^%./", ""):gsub("/+$", "")
        if relative ~= "" then
            safe(stage, relative)
            local key = relative:lower()
            if names[key] then error("Duplicate archive entry: " .. relative, 0) end
            names[key] = true
        end
    end
    local expected_files = 0
    local verbose = command("tar.exe -tvf " .. quote(zip) .. " 2>&1")
    for line in verbose:gmatch("[^\r\n]+") do
        if not line:match("^[-d]") then error("Links or unsupported archive entries are not allowed", 0) end
        if line:sub(1, 1) == "-" then expected_files = expected_files + 1 end
    end
    command("tar.exe -xf " .. quote(zip) .. " -C " .. quote(stage) .. " 2>&1")
    local files = {}
    for _, entry in ipairs(checked(fs.list_recursive(stage))) do
        local absolute = normal(entry.path)
        if not inside(stage, absolute) then error("Extracted path outside staging directory", 0) end
        local relative = absolute:sub(#normal(stage) + 2)
        local target = safe(stage, relative)
        if entry.is_symlink or fs.is_symlink(target) then error("Extracted links are not allowed", 0) end
        -- tar may list names in the Windows ANSI code page. Validate actual
        -- filesystem paths independently and require the full regular-file count.
        if entry.is_file then
            files[#files + 1] = {path=relative, source=target, hash=hash(target)}
        end
    end
    if #files == 0 then error("Fix archive contains no files", 0) end
    if #files ~= expected_files then error("Archive extraction is incomplete", 0) end
    return files
end
local function apply(options)
    local root, records, kind = options.root, options.records, options.kind
    local manifest = fs.join(records, "manifest.json")
    if fs.exists(manifest) then error("Remove the applied fix before applying another one", 0) end
    local pending = read_record(fs.join(records, "pending.json"))
    if pending then
        validate_record(pending, root, pending.kind)
        restore(root, records, pending, true)
    end
    local removing = read_record(fs.join(records, "removing.json"))
    if removing then
        validate_record(removing, root, removing.kind)
        restore(root, records, removing, true)
    end
    local expected = "https://github.com/skyflarefox/fix/releases/download/fix/" .. options.appid .. "_" .. kind .. ".zip"
    if options.url ~= expected then error("Invalid fix source", 0) end
    local id = native.uuid()
    local work_name = "stage-" .. id
    local zip = safe(records, "download-" .. id .. ".zip")
    local journal_saved, committed = false, false
    local record = {version=2, root=root, kind=kind, files={}, appliedAt=os.time()}
    local ok, err = pcall(function()
        command("curl.exe --fail --location --silent --show-error --connect-timeout 30 --max-time 300 --output " .. quote(zip) .. " " .. quote(expected) .. " 2>&1")
        options.state("extracting")
        local files = unpack_archive(zip, records, work_name)
        local backup_root = safe(records, "backup")
        for _, entry in ipairs(files) do
            local target = safe(root, entry.path)
            local original_hash = hash(target)
            if original_hash then
                local backup = safe(backup_root, entry.path)
                copy(target, backup)
                if hash(backup) ~= original_hash then error("Original file changed during backup", 0) end
            end
            record.files[#record.files + 1] = {path=entry.path, original=original_hash~=nil, originalHash=original_hash, hash=entry.hash}
        end
        write_record(fs.join(records, "pending.json"), record)
        journal_saved = true
        for i, entry in ipairs(files) do
            local target = safe(root, entry.path)
            if hash(target) ~= record.files[i].originalHash then error("File changed during fix application: " .. entry.path, 0) end
            copy(entry.source, target)
            if hash(target) ~= entry.hash then error("Fix verification failed: " .. entry.path, 0) end
        end
        write_record(manifest, record)
        committed = true
        remove(fs.join(records, "pending.json"))
    end)
    if not ok and journal_saved and not committed then
        local recovered, failure = pcall(restore, root, records, record, true)
        if not recovered then err = tostring(err) .. "; pending recovery: " .. tostring(failure) end
    end
    pcall(wipe_work, records, work_name)
    pcall(remove, zip)
    if not ok then error(err, 0) end
end
function engine.run(options)
    local key = normal(options.records):lower()
    if running[key] then return {success=false, error="A fix operation is already in progress"} end
    if not tostring(options.appid):match("^%d+$") or (options.kind ~= "generic" and options.kind ~= "online") or (options.operation ~= "apply" and options.operation ~= "remove") then return {success=false, error="Invalid fix operation"} end
    running[key] = true
    local function active_kind()
        local ok, record = pcall(read_record, fs.join(options.records, "manifest.json"))
        return ok and record and record.kind or ""
    end
    local function state(status, message)
        write_record(fs.join(options.records, "state.json"), {status=status, error=message or "", appliedKind=active_kind(), operation=options.operation})
    end
    options.state = state
    local ok, err = pcall(function()
        if not fs.is_directory(options.root) then error("Game folder not found", 0) end
        mkdir(options.records)
        state(options.operation == "apply" and "downloading" or "extracting")
        if options.operation == "apply" then apply(options) else
            local record = read_record(fs.join(options.records, "manifest.json")) or read_record(fs.join(options.records, "pending.json"))
            validate_record(record, options.root, options.kind)
            restore(options.root, options.records, record, true)
        end
        state("done")
    end)
    if not ok then pcall(state, "failed", tostring(err)) end
    running[key] = nil
    if not ok then return {success=false, error=tostring(err)} end
    return {success=true}
end
function engine.is_running(records)
    return running[normal(records):lower()] == true
end
return engine
