-- Remove only this plugin's fix records after a confirmed Steam uninstall.
local fs = require("fs")
local native = require("utils")
local paths = require("paths")
local steam = require("steam_utils")
local json = require("json")
local engine = require("fix_engine")
local logger = require("plugin_logger")
local cleanup = {}
local missing_since = {}
local last_scan = nil
local INTERVAL, GRACE = 5, 0

local function normal(path)
    return fs.absolute(path):gsub("\\", "/"):gsub("/+$", ""):lower()
end
local function checked(value)
    if value == nil or value == false then error("Fix cleanup filesystem read failed") end
    return value
end
local function read_record(path)
    if not fs.exists(path) then return nil end
    local record = json.decode(checked(native.read_file(path)))
    if type(record) ~= "table" then error("Invalid fix cleanup record") end
    return record
end
local function libraries()
    local base = steam.detect_steam_install_path()
    if not base or base == "" then error("Steam path unavailable") end
    local config = fs.join(base, "steamapps", "libraryfolders.vdf")
    if not fs.exists(config) then config = fs.join(base, "config", "libraryfolders.vdf") end
    local text = checked(native.read_file(config))
    if text == "" then error("Steam library configuration unavailable") end
    local roots, seen, installed = {}, {}, {}
    local function add(path)
        local key = normal(path)
        if not seen[key] then
            seen[key] = true
            roots[#roots + 1] = path
        end
    end
    add(base)
    local count = 0
    for path in text:gmatch('"path"%s+"([^"]+)"') do
        add(path:gsub("\\\\", "\\"))
        count = count + 1
    end
    if count == 0 then error("Steam library paths could not be parsed") end
    for _, root in ipairs(roots) do
        local apps = fs.join(root, "steamapps")
        -- An unplugged drive, permission error, or unreadable library is not an uninstall.
        if not fs.is_directory(apps) then error("A Steam library is unavailable") end
        for _, entry in ipairs(checked(fs.list(apps))) do
            local id = tostring(entry.name or ""):match("^appmanifest_(%d+)%.acf$")
            if id then installed[id] = true end
        end
    end
    -- Steam may update its library index and appmanifest at different times.
    for apps in text:gmatch('"apps"%s*{(.-)}') do
        for id in apps:gmatch('"(%d+)"%s+"%d+"') do installed[id] = true end
    end
    return seen, installed
end

local function sweep()
    local now = os.time()
    if last_scan and now - last_scan < INTERVAL then return {success=true, removed=0} end
    last_scan = now
    local root = paths.backend_path("data/fixes")
    if not fs.exists(root) then missing_since = {}; return {success=true, removed=0} end
    if fs.is_symlink(root) then error("Linked fix record root is not supported") end
    local known, installed = libraries()
    local removed, present = 0, {}
    for _, entry in ipairs(checked(fs.list(root))) do
        local id = tostring(entry.name or "")
        if id:match("^%d+$") then
            present[id] = true
            local directory = fs.join(root, id)
            local eligible = false
            if installed[id] then
                missing_since[id] = nil
            elseif fs.is_directory(directory) and not fs.is_symlink(directory) and not engine.is_running(directory) then
                local record = read_record(fs.join(directory, "manifest.json")) or read_record(fs.join(directory, "pending.json"))
                if record and type(record.root) == "string" then
                    local library = normal(record.root):match("^(.-)/steamapps/common/.+")
                    -- A removed/unregistered library is ambiguous; preserve its backups.
                    eligible = library ~= nil and known[library] == true
                end
            end
            if eligible then
                missing_since[id] = missing_since[id] or now
                if now - missing_since[id] >= GRACE then
                    local target, parent = normal(directory), normal(root)
                    if target ~= parent .. "/" .. id then error("Fix cleanup target outside record root") end
                    if normal(checked(fs.canonical(directory))) ~= normal(checked(fs.canonical(root))) .. "/" .. id then error("Linked fix cleanup target") end
                    -- No symlinks anywhere in the recursive deletion target.
                    for _, child in ipairs(checked(fs.list_recursive(directory))) do
                        if child.is_symlink or fs.is_symlink(child.path) then error("Linked fix backup entry") end
                    end
                    checked(fs.remove_all(directory))
                    if fs.exists(directory) then error("Fix cleanup did not finish") end
                    missing_since[id] = nil
                    removed = removed + 1
                    logger.log("Removed uninstalled game fix records: " .. id)
                end
            elseif not installed[id] then missing_since[id] = nil end
        end
    end
    for id in pairs(missing_since) do if not present[id] then missing_since[id] = nil end end
    return {success=true, removed=removed}
end
function cleanup.sweep()
    local ok, result = pcall(sweep)
    if not ok then
        -- Require a new continuous confirmation period after any ambiguous read.
        missing_since = {}
        logger.warn("Fix cleanup deferred: " .. tostring(result))
        return {success=false, error=tostring(result)}
    end
    return result
end
return cleanup
