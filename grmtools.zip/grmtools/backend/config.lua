local config = {
    WEBKIT_DIR_NAME = "GRMTools",
    WEB_UI_JS_FILE = "grmtools.js",
    WEB_UI_ICON_FILE = "grmtools-icon.png",

    DEFAULT_HEADERS = {
        ["Accept"] = "application/json",
        ["X-Requested-With"] = "SteamDB",
        ["User-Agent"] = "https://github.com/BossSloth/Steam-SteamDB-extension",
        ["Origin"] = "https://github.com/BossSloth/Steam-SteamDB-extension",
        ["Sec-Fetch-Dest"] = "empty",
        ["Sec-Fetch-Mode"] = "cors",
        ["Sec-Fetch-Site"] = "cross-site",
    },

    API_MANIFEST_URL = "https://raw.githubusercontent.com/JuniorSantana93/files/refs/heads/main/api/api.json",
    API_MANIFEST_PROXY_URL = "https://raw.githubusercontent.com/JuniorSantana93/files/refs/heads/main/api/api.json",
    API_JSON_FILE = "api.json",


    HTTP_TIMEOUT_SECONDS = 15,
    HTTP_PROXY_TIMEOUT_SECONDS = 15,


    USER_AGENT = "GRMTools",

    LOADED_APPS_FILE = "loadedappids.txt",
    APPID_LOG_FILE = "appidlogs.txt",
}

return config
